type RoadRow = {
  roundNo: number;
  playerPoint: number;
  bankerPoint: number;
  winner: "閒" | "莊" | "和" | "";
  playerPair: boolean;
  bankerPair: boolean;
};

type RoadCell = {
  col: number;
  row: number;
  winner: "閒" | "莊";
  ties: number;
  point: number;
  playerPair: boolean;
  bankerPair: boolean;
};

function buildRoad(rows: RoadRow[]) {
  const cells = new Map<string, RoadCell>();
  let last: RoadCell | undefined;
  let lastWinner: "閒" | "莊" | undefined;
  for (const data of rows) {
    if (data.winner === "和") {
      if (last) last.ties += 1;
      continue;
    }
    if (data.winner !== "閒" && data.winner !== "莊") continue;
    let col = 0;
    let row = 0;
    if (last) {
      if (data.winner === lastWinner) {
        const nextRow = last.row + 1;
        if (nextRow < 6 && !cells.has(`${last.col}:${nextRow}`)) {
          col = last.col;
          row = nextRow;
        } else {
          col = last.col + 1;
          row = last.row;
          while (cells.has(`${col}:${row}`)) col += 1;
        }
      } else {
        col = last.col + 1;
        while (cells.has(`${col}:0`)) col += 1;
      }
    }
    const cell: RoadCell = { col, row, winner: data.winner, ties: 0, point: data.winner === "閒" ? data.playerPoint : data.bankerPoint, playerPair: data.playerPair, bankerPair: data.bankerPair };
    cells.set(`${col}:${row}`, cell);
    last = cell;
    lastWinner = data.winner;
  }
  return Array.from(cells.values());
}

export function BigRoad({ rows }: { rows: RoadRow[] }) {
  const cells = buildRoad(rows);
  const columns = Math.max(30, ...cells.map(cell => cell.col + 3));
  return <div className="mt-5 rounded-2xl border border-[#E7EAF0] bg-white p-5 shadow-[0_8px_28px_rgba(21,36,59,0.045)] sm:p-6"><div className="mb-4 flex items-center justify-between gap-3"><div><p className="text-xs font-semibold tracking-[0.15em] text-[#A27C2E]">BIG ROAD</p><h2 className="mt-1 font-serif text-2xl font-semibold text-[#15243B]">大路圖</h2></div><p className="text-xs text-slate-400">六列 · 可橫向捲動</p></div><div className="overflow-x-auto rounded-sm border border-[#B8B8B8] bg-[#F5F5F5]"><div className="grid min-w-max" style={{ gridTemplateColumns: `repeat(${columns}, 32px)`, gridTemplateRows: "repeat(6, 32px)" }}>{Array.from({ length: columns * 6 }, (_, index) => <div key={index} className="border-b border-r border-[#B8B8B8]" />)}{cells.map(cell => <RoadMark key={`${cell.col}-${cell.row}`} cell={cell} />)}</div></div><div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500"><span><i className="mr-1 inline-block size-2.5 rounded-full border-2 border-[#0057FF] align-middle" />閒</span><span><i className="mr-1 inline-block size-2.5 rounded-full border-2 border-[#E00000] align-middle" />莊</span><span><i className="mr-1 inline-block h-0.5 w-3 -rotate-45 bg-[#009B3A] align-middle" />和局</span><span>左下藍點：閒對；右下紅點：莊對</span></div></div>;
}

function RoadMark({ cell }: { cell: RoadCell }) {
  const tone = cell.winner === "閒" ? "border-[#0057FF] text-[#0057FF]" : "border-[#E00000] text-[#E00000]";
  return <div style={{ gridColumn: cell.col + 1, gridRow: cell.row + 1 }} className="relative flex items-center justify-center"><div className={`relative flex size-5 items-center justify-center rounded-full border-2 text-[9px] font-bold ${tone}`}>{cell.point}{cell.ties > 0 && <i className="absolute left-0.5 top-2 h-0.5 w-4 -rotate-45 bg-[#009B3A]" />}{cell.playerPair && <i className="absolute -bottom-1 -left-1 size-1.5 rounded-full bg-[#0057FF]" />}{cell.bankerPair && <i className="absolute -bottom-1 -right-1 size-1.5 rounded-full bg-[#E00000]" />}</div></div>;
}
