import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronDown, Crown, Equal, ShieldCheck, XCircle } from "lucide-react";

type Prediction = "閒" | "莊" | "和" | "";

export type DetailedFormula = {
  name: string;
  value: number | null;
  nextPrediction: Prediction;
  success: boolean;
  error: string;
  previousPrediction: Prediction;
  status: "hit" | "miss" | "pending";
};

export type DetailedHistoryRow = {
  id?: number;
  tableId: string;
  roundNo: number;
  playerWins: number;
  bankerWins: number;
  tieCount: number;
  playerCards: number[];
  bankerCards: number[];
  playerPoint: number;
  bankerPoint: number;
  winner: Prediction;
  playerPair: boolean;
  bankerPair: boolean;
  formulas: DetailedFormula[];
};

function cardLabel(value: number) {
  return ({ 1: "A", 11: "J", 12: "Q", 13: "K" } as Record<number, string>)[value] ?? String(value);
}

function predictionTone(value: Prediction) {
  if (value === "閒") return "border-[#BFDDF5] bg-[#F4FAFF] text-[#1C69B3]";
  if (value === "莊") return "border-[#F2CBCC] bg-[#FFF7F7] text-[#B64A4A]";
  if (value === "和") return "border-[#C5E6D4] bg-[#F1FBF5] text-[#28764E]";
  return "border-[#E3E8EF] bg-[#FAFBFC] text-slate-400";
}

function StatusBadge({ status }: { status: DetailedFormula["status"] }) {
  if (status === "hit") return <Badge className="border-0 bg-[#19734B] text-white hover:bg-[#19734B]"><ShieldCheck className="mr-1 size-3" />命中</Badge>;
  if (status === "miss") return <Badge className="border-0 bg-[#B64A4A] text-white hover:bg-[#B64A4A]"><XCircle className="mr-1 size-3" />未命中</Badge>;
  return <Badge variant="outline" className="border-[#DCE4EE] bg-white text-slate-500"><Equal className="mr-1 size-3" />待驗證</Badge>;
}

function SideCards({ label, cards, point, pair, tone }: { label: "閒" | "莊"; cards: number[]; point: number; pair: boolean; tone: "player" | "banker" }) {
  const color = tone === "player" ? "text-[#1C69B3]" : "text-[#B64A4A]";
  const border = tone === "player" ? "border-[#D7E7F6] bg-[#F8FBFF]" : "border-[#F1D9DA] bg-[#FFF9F9]";
  return <div className={`rounded-xl border p-3 ${border}`}><div className="flex items-center justify-between gap-3"><span className={`font-serif text-lg font-semibold ${color}`}>{label}</span><span className="font-serif text-xl font-bold text-[#15243B]">{point}<small className="ml-1 font-sans text-xs font-medium text-slate-400">點</small></span></div><div className="mt-2 flex flex-wrap gap-1.5">{cards.length ? cards.map((card, index) => <span key={`${label}-${index}`} className="inline-flex min-w-8 items-center justify-center rounded-md border border-white bg-white px-2 py-1 text-sm font-bold text-[#203956] shadow-sm">{cardLabel(card)}</span>) : <span className="text-xs text-slate-400">無牌面資料</span>}</div>{pair && <p className="mt-2 text-xs font-medium text-[#8A6725]">{label}對</p>}</div>;
}

export function DetailedHistoryResults({ items, loading }: { items: DetailedHistoryRow[]; loading: boolean }) {
  if (loading) return <p className="mt-5 rounded-xl border border-dashed border-[#E3E7EE] bg-[#FAFBFC] px-4 py-5 text-sm text-slate-400">正在載入完整歷史資料與公式結果…</p>;
  if (!items.length) return <p className="mt-5 rounded-xl border border-dashed border-[#E3E7EE] bg-[#FAFBFC] px-4 py-5 text-sm leading-6 text-slate-500">尚無本桌公式紀錄；確認並儲存第一局後，這裡會顯示輸入牌面、點數、勝負及所有公式結果。</p>;

  return <div className="mt-5 space-y-4" data-testid="detailed-history-results">{items.map(row => <details key={row.id ?? row.roundNo} open className="group overflow-hidden rounded-2xl border border-[#E3E8EF] bg-[#FCFDFE] shadow-[0_4px_14px_rgba(21,36,59,0.035)]"><summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-4 py-3.5 transition hover:bg-white [&::-webkit-details-marker]:hidden"><div className="min-w-0"><p className="text-[10px] font-bold tracking-[0.16em] text-[#A27C2E]">ROUND {row.roundNo}</p><p className="mt-1 text-sm font-semibold text-[#1C314D]">使用者輸入、計算點數、實際勝負與全部公式結果</p></div><div className="flex shrink-0 items-center gap-2"><Badge className={`border ${predictionTone(row.winner)}`}>實際：{row.winner || "—"}</Badge><ChevronDown className="size-4 text-slate-400 transition-transform group-open:rotate-180" /></div></summary><div className="border-t border-[#E9EDF2] bg-white p-4 sm:p-5"><div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_180px]"><SideCards label="閒" cards={row.playerCards} point={row.playerPoint} pair={row.playerPair} tone="player" /><SideCards label="莊" cards={row.bankerCards} point={row.bankerPoint} pair={row.bankerPair} tone="banker" /><div className="rounded-xl border border-[#E4D7B5] bg-[#FFFCF4] p-3"><p className="text-[10px] font-bold tracking-[0.14em] text-[#9A762B]">本局結果</p><p className={`mt-2 font-serif text-3xl font-bold ${row.winner === "閒" ? "text-[#1C69B3]" : row.winner === "莊" ? "text-[#B64A4A]" : "text-[#28764E]"}`}>{row.winner || "—"}</p><p className="mt-2 text-xs leading-5 text-slate-500">累計：閒 {row.playerWins} · 莊 {row.bankerWins} · 和 {row.tieCount}</p></div></div><div className="mt-5"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold tracking-[0.14em] text-[#A27C2E]">ALL FORMULA RESULTS</p><h3 className="mt-1 font-serif text-xl font-semibold text-[#15243B]">全部公式結果</h3></div><p className="text-xs text-slate-400">「上局預測本局」依 app.py 命中規則對照本局實際勝負</p></div><div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{row.formulas.map(formula => <Card key={formula.name} className="rounded-xl border-[#E4E9F0] bg-[#FCFDFE] shadow-none"><CardContent className="p-3"><div className="flex items-start justify-between gap-2"><p className="font-semibold text-[#1D3653]">{formula.name}</p><StatusBadge status={formula.status} /></div><div className="mt-3 grid grid-cols-2 gap-2 text-xs"><Metric label="公式值" value={formula.value === null ? "—" : String(formula.value)} /><Metric label="上局預測本局" value={formula.previousPrediction || "—"} className={predictionTone(formula.previousPrediction)} /><Metric label="下局預測" value={formula.nextPrediction || "—"} className={predictionTone(formula.nextPrediction)} /><Metric label="計算狀態" value={formula.success ? "有效" : formula.error || "無結果"} /></div></CardContent></Card>)}</div></div></div></details>)}</div>;
}

function Metric({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return <div className={`min-w-0 rounded-lg border border-[#EEF1F5] bg-white px-2 py-1.5 ${className}`}><p className="text-[10px] text-slate-400">{label}</p><p className="mt-0.5 truncate font-semibold text-[#31445E]" title={value}>{value}</p></div>;
}
