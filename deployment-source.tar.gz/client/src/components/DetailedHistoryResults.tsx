import { Badge } from "@/components/ui/badge";
import { Check, Minus, X } from "lucide-react";

type Prediction = "閒" | "莊" | "和" | "";

export type DetailedFormula = {
  name: string;
  value: number | null;
  nextPrediction: Prediction;
  success: boolean;
  error: string;
  previousPrediction: Prediction;
  status: "hit" | "miss" | "pending";
};

export type DetailedHistoryRow = {
  id?: number;
  tableId: string;
  roundNo: number;
  playerWins: number;
  bankerWins: number;
  tieCount: number;
  playerCards: number[];
  bankerCards: number[];
  playerPoint: number;
  bankerPoint: number;
  winner: Prediction;
  playerPair: boolean;
  bankerPair: boolean;
  formulas: DetailedFormula[];
};

const HISTORY_VISIBLE_ROWS = 9;
const baseHeaders = ["局數", "閒1", "閒2", "閒3", "莊1", "莊2", "莊3", "閒點", "莊點", "結果"];

function cardLabel(value?: number) {
  if (value === undefined) return "";
  return ({ 1: "A", 11: "J", 12: "Q", 13: "K" } as Record<number, string>)[value] ?? String(value);
}

function predictionClass(value: Prediction) {
  if (value === "閒") return "text-[#0057FF]";
  if (value === "莊") return "text-[#E00000]";
  if (value === "和") return "text-[#009B3A]";
  return "text-slate-400";
}

function FormulaCell({ formula, next = false }: { formula: DetailedFormula; next?: boolean }) {
  const prediction = next ? formula.nextPrediction : formula.previousPrediction;
  const hit = !next && formula.status === "hit";
  const miss = !next && formula.status === "miss";
  return <td title={next ? `${formula.name} 下局運算值：${formula.value ?? "—"}` : `${formula.name} 本局運算值：${formula.value ?? "—"}`} className={`min-w-[56px] border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center align-middle ${hit ? "bg-[#E00000] text-white" : "bg-white"}`}><span className={`inline-flex items-center justify-center gap-0.5 font-bold ${hit ? "text-white" : predictionClass(prediction)}`}>{prediction || ""}{hit && <Check className="size-3" />}{miss && <X className="size-3 text-[#E00000]" />}</span></td>;
}

export function DetailedHistoryResults({ items, loading }: { items: DetailedHistoryRow[]; loading: boolean }) {
  if (loading) return <p className="mt-5 rounded-xl border border-dashed border-[#E3E7EE] bg-[#FAFBFC] px-4 py-5 text-sm text-slate-400">正在載入 app.py 相容歷史表格…</p>;
  if (!items.length) return <p className="mt-5 rounded-xl border border-dashed border-[#E3E7EE] bg-[#FAFBFC] px-4 py-5 text-sm leading-6 text-slate-500">尚無本桌公式紀錄；確認並儲存第一局後，這裡會顯示 app.py 相容的牌面、點數、結果與全部公式表格。</p>;

  const chronological = [...items].reverse();
  const displayRows = chronological.slice(-HISTORY_VISIBLE_ROWS);
  const formulaNames = chronological[0]?.formulas.map(formula => formula.name) ?? [];
  const formulaHits = Object.fromEntries(formulaNames.map(name => [name, chronological.reduce((total, row) => total + (row.formulas.find(formula => formula.name === name)?.status === "hit" ? 1 : 0), 0)]));
  const streaks = Object.fromEntries(formulaNames.map(name => {
    const results = chronological.map(row => row.formulas.find(formula => formula.name === name)?.status).filter((status): status is "hit" | "miss" => status === "hit" || status === "miss");
    const latest = results.at(-1);
    let count = latest ? 1 : 0;
    for (let index = results.length - 2; index >= 0 && results[index] === latest; index -= 1) count += 1;
    return [name, { status: latest, count }];
  }));
  const highestWin = Math.max(0, ...formulaNames.map(name => streaks[name]?.status === "hit" ? streaks[name].count : 0));
  const highestLoss = Math.max(0, ...formulaNames.map(name => streaks[name]?.status === "miss" ? streaks[name].count : 0));
  const allHitCounts = Object.values(formulaHits);
  const highestHit = Math.max(...allHitCounts);
  const lowestHit = Math.min(...allHitCounts);
  const latest = chronological.at(-1)!;

  return <div className="mt-5" data-testid="detailed-history-results"><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold tracking-[0.14em] text-[#A27C2E]">FORMULA HISTORY TABLE</p><h3 className="mt-1 font-serif text-xl font-semibold text-[#15243B]">歷史資料表格</h3></div><div className="flex items-center gap-2"><Badge variant="outline" className="border-[#DCE4EE] bg-white text-slate-500">紅底：命中</Badge><Badge variant="outline" className="border-[#DCE4EE] bg-white text-slate-500">顯示最新 {Math.min(items.length, HISTORY_VISIBLE_ROWS)} 筆</Badge></div></div><p className="mb-3 text-xs leading-5 text-slate-500">欄位、公式順序與列結構依 app.py：實際列用前一局預測驗證本局；「下一局」為最新局計算預測；最下列為各公式命中數。</p><div className="overflow-x-auto rounded-sm border border-[#BDBDBD] bg-white"><table className="min-w-[1560px] border-collapse text-xs"><thead className="bg-[#EEEEEE]"><tr>{baseHeaders.map(header => <th key={header} className="min-w-[54px] border-b border-r border-[#BDBDBD] px-1 py-2 text-center font-bold text-black">{header}</th>)}{formulaNames.map(name => { const streak = streaks[name]; const className = streak?.status === "hit" && streak.count === highestWin && highestWin > 0 ? "text-[#E00000]" : streak?.status === "miss" && streak.count === highestLoss && highestLoss > 0 ? "text-[#0057FF]" : "text-black"; return <th key={name} className={`min-w-[56px] border-b border-r border-[#BDBDBD] px-1 py-2 text-center font-bold ${className}`}>{name}</th>; })}</tr></thead><tbody>{displayRows.map(row => { const playerCards = Array.from({ length: 3 }, (_, index) => row.playerCards[index]); const bankerCards = Array.from({ length: 3 }, (_, index) => row.bankerCards[index]); return <tr key={row.id ?? row.roundNo}><td className="border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center">{row.roundNo}</td>{playerCards.map((card, index) => <td key={`p-${index}`} className="border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center">{cardLabel(card)}</td>)}{bankerCards.map((card, index) => <td key={`b-${index}`} className="border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center">{cardLabel(card)}</td>)}<td className="border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center">{row.playerPoint}</td><td className="border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center">{row.bankerPoint}</td><td className={`border-b border-r border-[#CFCFCF] px-1 py-1.5 text-center font-bold ${predictionClass(row.winner)}`}>{row.winner}</td>{row.formulas.map(formula => <FormulaCell key={formula.name} formula={formula} />)}</tr>; })}<tr className="bg-[#EEEEEE]"><td colSpan={10} className="border-b border-r border-[#BDBDBD] px-2 py-2 text-left font-bold text-black">下一局 {latest.roundNo + 1}</td>{latest.formulas.map(formula => <FormulaCell key={formula.name} formula={formula} next />)}</tr><tr className="bg-white"><td colSpan={10} className="border-r border-[#BDBDBD] px-2 py-2 text-left font-bold text-black">命中數</td>{formulaNames.map(name => { const count = formulaHits[name]; return <td key={name} className={`border-r border-[#CFCFCF] px-1 py-2 text-center font-bold ${count === highestHit ? "text-[#E00000]" : count === lowestHit ? "text-[#0057FF]" : "text-black"}`}>{count}</td>; })}</tr></tbody></table></div><div className="mt-2 flex items-center gap-1.5 text-xs text-slate-400"><Minus className="size-3" /> 可向右捲動查看所有公式欄位；格內停留可查看該公式的運算值。</div></div>;
}
