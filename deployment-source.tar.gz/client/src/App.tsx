import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AnalysisPage from "./pages/AnalysisPage";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";

function Router() {
  return <main className="min-h-screen bg-[#F5F6F8] p-4 sm:p-6 lg:p-8"><Switch><Route path="/" component={Home} /><Route path="/analysis" component={AnalysisPage} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch></main>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
