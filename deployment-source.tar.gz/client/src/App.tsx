import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import DashboardLayout from "./components/DashboardLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import CardsPage from "./pages/CardsPage";
import CsvPage from "./pages/CsvPage";
import AnalysisPage from "./pages/AnalysisPage";
import CustomFormulasPage from "./pages/CustomFormulasPage";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import StoragePage from "./pages/StoragePage";

function Router() {
  return <DashboardLayout><Switch><Route path="/" component={Home} /><Route path="/analysis" component={AnalysisPage} /><Route path="/custom-formulas" component={CustomFormulasPage} /><Route path="/cards" component={CardsPage} /><Route path="/storage" component={StoragePage} /><Route path="/csv" component={CsvPage} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch></DashboardLayout>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
