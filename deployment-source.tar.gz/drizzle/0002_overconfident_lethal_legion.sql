CREATE TABLE `customFormulas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`rules` json NOT NULL,
	`isEnabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customFormulas_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `custom_formula_user_enabled_idx` ON `customFormulas` (`userId`,`isEnabled`);--> statement-breakpoint
CREATE INDEX `custom_formula_user_created_idx` ON `customFormulas` (`userId`,`createdAt`);