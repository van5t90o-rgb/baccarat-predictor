CREATE TABLE `cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`card` varchar(2) NOT NULL,
	`numericValue` int NOT NULL,
	`baccaratValue` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cards_id` PRIMARY KEY(`id`),
	CONSTRAINT `cards_user_card_unique` UNIQUE(`userId`,`card`)
);
--> statement-breakpoint
CREATE TABLE `eventRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventName` varchar(32) NOT NULL,
	`tableId` varchar(64) NOT NULL,
	`roundNo` int NOT NULL,
	`點差` varchar(1) NOT NULL,
	`理數` varchar(1) NOT NULL,
	`導數` varchar(1) NOT NULL,
	`真數` varchar(1) NOT NULL,
	`HZ` varchar(1) NOT NULL,
	`價值` varchar(1) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `eventRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `formulaRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tableId` varchar(64) NOT NULL,
	`roundNo` int NOT NULL,
	`playerWins` int NOT NULL,
	`bankerWins` int NOT NULL,
	`tieCount` int NOT NULL,
	`playerCards` json NOT NULL,
	`bankerCards` json NOT NULL,
	`playerPoint` int NOT NULL,
	`bankerPoint` int NOT NULL,
	`winner` varchar(1) NOT NULL,
	`playerPair` boolean NOT NULL DEFAULT false,
	`bankerPair` boolean NOT NULL DEFAULT false,
	`formulas` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `formulaRecords_id` PRIMARY KEY(`id`),
	CONSTRAINT `formula_user_table_round_unique` UNIQUE(`userId`,`tableId`,`roundNo`)
);
--> statement-breakpoint
CREATE INDEX `cards_user_card_idx` ON `cards` (`userId`,`card`);--> statement-breakpoint
CREATE INDEX `event_user_name_idx` ON `eventRecords` (`userId`,`eventName`);--> statement-breakpoint
CREATE INDEX `event_user_table_idx` ON `eventRecords` (`userId`,`tableId`,`roundNo`);--> statement-breakpoint
CREATE INDEX `formula_user_table_round_idx` ON `formulaRecords` (`userId`,`tableId`,`roundNo`);--> statement-breakpoint
CREATE INDEX `formula_user_winner_idx` ON `formulaRecords` (`userId`,`winner`);